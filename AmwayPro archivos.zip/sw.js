// ═══════════════════════════════════════════
// AmwayPro — Service Worker v3
// Estrategia: Cache-First para el shell de la app.
// Los DATOS (IndexedDB / localStorage) NUNCA son
// tocados por el SW; solo se cachea el HTML/assets.
// ═══════════════════════════════════════════
const CACHE = 'amwaypro-shell-v3';

const SHELL = [
  './',
  './AmwayPro_v9.html',
  './manifest.json',
  './icon-192.png',
  './icon-512.png',
];

self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE).then(cache => {
      return Promise.allSettled(
        SHELL.map(url => cache.add(url).catch(() => {}))
      );
    }).then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys =>
      Promise.all(
        keys.filter(k => k !== CACHE).map(k => caches.delete(k))
      )
    ).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', event => {
  if (event.request.method !== 'GET') return;
  const url = new URL(event.request.url);
  if (url.origin !== self.location.origin) return;

  event.respondWith(
    caches.match(event.request).then(cached => {
      if (cached) return cached;
      return fetch(event.request).then(response => {
        if (response && response.status === 200) {
          const clone = response.clone();
          caches.open(CACHE).then(cache => cache.put(event.request, clone));
        }
        return response;
      }).catch(() => {
        return caches.match('./AmwayPro_v9.html');
      });
    })
  );
});
